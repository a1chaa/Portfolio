
def main():
    nums = []
    for i in range(1, 11):
        print(nums)
        nums.append(i*i)
    print(nums)

main()
