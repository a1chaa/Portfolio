from graphics import *


def main():
    win = GraphWin()
    p = Point(100,100)
    circ = Circle(p, 30)
    circ.setFill("blue")
    circ.draw(win)

    label = Text(p, "Circle")
    label.draw(win)

    p2 = Point(5,5)
    p2.draw(win)

    p3 = Point(140, 70)
    p3.draw(win)

    #r1 = Point(30,30)
    #r2 = Point(70,70)
    rect = Rectangle(Point(30,30), Point(70,70))
    rect.setFill("orange")
    rect.draw(win)

main()
