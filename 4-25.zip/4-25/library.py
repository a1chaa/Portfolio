class Book:
    def __init__(self, title, author, year):
        self.title = title
        self.author = author
        self.year = year
        self.shelf = 0 #initially not on a shelf

    def getTitle(self):
        return self.title

    def getAuthor(self):
        return self.author

    def getYear(self):
        return self.year

    def getLocation(self):
        return self.shelf

    def putOnShelf(self, shelfno):
        self.shelf = shelfno

    def __repr__(self):
        s = self.title + " by " + self.author + ", " + str(self.year)
        return s

class Library:
    def __init__(self):
        self.books = {}

    def addBook(self, b):
        self.books[b.getTitle()] = b

    def findBook(self, title):
        b = self.books[title]
        return b.getLocation()

    def placeBook(self, title, shelf):
        b = self.books[title]
        b.putOnShelf(shelf)

    def getAllBooks(self):
        k = list(self.books.keys())
        for i in range(len(k)):
            print(self.books[k[i]])


def main():
    lib = Library()
    b1 = Book("Dune", "Frank Herbert", 1971)
    b2 = Book("Twilight", "Stephanie Meyer", 2005)
    b3 = Book("Fake Book", "Secret Person", 2024)
    lib.addBook(b1)
    lib.addBook(b2)
    lib.addBook(b3)

    lib.getAllBooks()

    lib.placeBook("Dune", 1)
    lib.placeBook("Fake Book", 3)

    print(lib.findBook("Dune"))
    print(lib.findBook("Twilight"))
    print(lib.findBook("Fake Book"))

main()
