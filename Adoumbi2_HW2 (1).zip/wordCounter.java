/* Name: AICHATA
* Netid: ADOUMBI2
* Assignment: Lab 2
* Lab section: MW 4:50
*
* I did not collaborate with anyone on this assignment.
*/
import java.util.Scanner;

public class wordCounter {
	public static void main (String [] args) {
		Scanner a = new Scanner(System.in);
		int word = 0;
		int line= 0;
		int character = 0;
		String input  = a.nextLine();
		while (!input.equals("quit")) {
			for (int x=0; x<input.length();x++) {
				if (!input.substring(x,x+1).equals(" "))  {
					character++;
				} 
				else {
					word++;
				}
			}
			
		if (input.length()>0)
			word++;
			line++;
			
			
			input=a.nextLine();
				
		}
		System.out.println("number of lines" + " " + line);
		System.out.println("number of letters" + " " + character);
		System.out.println ("number of words" +" " + word);
	}
}
			
		
