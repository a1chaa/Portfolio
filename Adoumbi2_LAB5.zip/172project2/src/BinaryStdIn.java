
public class BinaryStdIn {

	public static int readInt() {
		// TODO Auto-generated method stub
		return 0;
	}

	public static boolean readBoolean() {
		// TODO Auto-generated method stub
		return false;
	}

}
