
public class BinaryStdOut {

	public static void write(char ch) {
		// TODO Auto-generated method stub
		
	}

	public static void close() {
		// TODO Auto-generated method stub
		
	}

}
