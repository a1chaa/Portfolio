/* Name: AICHA
 * Netid: ADOUMBI2
 * Assignment: Lab 2
 * Lab section: MW 4:50
 *
 * I did not collaborate with anyone on this assignment.
 */
 
 
 
 In this catapult game you will have five shots ( but you can cheat to add more or less)! You will need to use the " cheat" command. 
 For example you can do cheat X Y Z. Cheat X is just for the shots Cheat X,Y is for the shots and quality, Cheat X,Y,Z is 
 for shots quality and distance. You will not be able to  set your quality or distance beyond the range. You can also  inspect your catapult and 
 know what type of quality is is , range , the angle and the velocity. Every round is began with five shots and once you get to zero you can
 reset or cheat to continue playing. Resetting creates a new round. You can set your own angle or velocity but not above the range that it is set 
 or else a warning messge will print. Then in order to play you can fire! which is not case sensitive.
 
 
 
 
 Hope this was good enough I have two minutes to submit. I worked really hard and I hope you rememeber I am a complete beginner. 
 Hopefully my code is clear and up to your standards.