/* Name: AICHA
* Netid: ADOUMBI2
* Assignment: Lab 2
* Lab section: MW 4:50
*
* I did not collaborate with anyone on this assignment.
*/
Welcome to my TIC-TAC-TOE GAME! In order to play the game, begin by selecting the board DIRECTLY in the middle, and restart to clear
the board. My class extends JPanel and begins with several variables.Player one is a boolean because, if it is not player one's turn, then it is player twos. 1 represents the X's and the 2's represents O's.
I then create my labels and button, along with customizing them. My constructor initializes the games background, size  and variables. I also add my labels and button 
to my panel. I then add a Mouse listener to react whenever the user clicks the button (restart()) or the game(repaint()). I then create my paint method
and design the label and placement for the turns and then create my game board by using drawrec and then adjusting the positions. I also select the colors 
that I want. I then create a for loop with a nested for and if that converts data from the array into the actual visual of the game. One represents x a
and I chose its color to be red, while two represents X. It goes through each square in the game board which I assigned variables for m,n. If there is
a one for a certain position in the array, then itll draw an X. If there is a two, then itll draw an O.Then after this method, I have an if statement designed to announce the winner based on who has a win player 1 
or 2( X or O).The final else if is for a draw when neither X or O wins, announce that there is a draw. I then use the graphics to display the score
and draw the X's and O's as well as their positions. After this is my reset method that clears the board of the game using for loops.This is then followed
by my draw method that checks to see if theyr'e draws by going through board array and seeing if The board is full/ completed based off of the completed boolean.
Next I have my win method that checks horizontally, vertically and diagonally.I created variables a b and c, and equaled them to board 
all within a for loop. Then in my nested if, a must equal b and b must equal c in order for there to be a draw. After that I create a class that implements MouseListeners.
I use an If statement . At the end I have another if that switches which players turn it is by having player1 equal true , and setting it to !player one
because if its not player ones turn then it is player twos turn. I then create several ifs to get the user to click within the board.This finally followed by another 
 if for the wins and  increment ones score. This goes for the draws and player 2's scores.