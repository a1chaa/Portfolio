///Aichata Doumbia
//README

CHANGES:
The methods in SurveyDataAnalyzer are without the CustomHashTable table as a parameter,
in order to be compatable withthe test cases, which are without parameters. 
The gender variable type was modified from string to integer, so that it 
can allign with resposnses.txt/test cases.



Main in SurveyDataAnalyzer::

Ensure you have the file named "responses.txt" containing survey responses.
Execute the main method.
View the analyzed survey data output in the console.
The main method in SurveyDataAnalyzer is the entry point for running the 
Survey Data Analyzer program. It reads responses from a file, 
performs various analyses on the survey data, and outputs the results to the console.

These blocks of code are responsible for calling methods from the analyzer object ( an instance of the SurveyDataAnalyzer class) 
to perform specific analyses on survey data and print the results to the console




Methods in SurveyDataAnalyzer:
Most of the methods are similar so I'll be explaining a single one 
and the rest of the similar ones should
function the same way.

first, I initialized a SurveyDataAnalyzer object with the data stored in the specified CustomHashTable, 
enabling subsequent analysis of the survey data within the SurveyDataAnalyzer instance.

genderDistribution(): an int [] array of size 4. This array contains the number of responses for each gender. 
Looping Through Responses: The loop iterates from 1 to 300, representing the IDs of the survey responses.
Retrieving Gender: For each iteration, it retrieves the Response object associated with the current ID from the CustomHashTable named table. Then, 
it retrieves the gender information from the Response object using the getter getGender() method and stores it in the variable gender.
Counting Gender: Based on the gender value obtained:
If gender is equal to 1, it increments the counter for the number of women at index 0 of the genderResponse array.
If gender is equal to 2, it increments the counter for the number of men at index 1 of the genderResponse array.
If gender is equal to 3, it increments the counter for another gender category (possibly designated for non-binary or unspecified) at index 2 of the genderResponse array.
If gender is equal to 4, it increments the counter for another gender category (possibly designated for non-binary or unspecified) at index 3 of the genderResponse array.
Returning the Result: After counting the genders for all responses, it returns the genderResponse array, which contains the counts of each gender category.



lifeQualityGeneral():calculates the average life quality based on responses stored in a CustomHashTable.
Variables:
totalQuality: This variable is used to accumulate the sum of the quality values obtained from each response.
Loop Through Responses:
The method iterates over each response in the table. It starts from response index 1 and goes up to 300.
For each response, it retrieves the corresponding Response object from the table using table.search(i) method.
It then gets the quality value of the response using value.getQuality() and adds it to the totalQuality.
Calculate Mean:
After iterating through all responses, the method divides the total quality by the number of responses (300) to get the average quality.
This calculated mean is stored in the variable mean.
Return Mean:
Finally, the method returns the calculated mean value, which represents the average life quality based on all responses in the table.

lifeQualityEducationBased():

calculates the average life quality based on the level of education of respondents stored in a CustomHashTable. 
Similarly in the other lifeQualities,
Variables:
Four variables (primary, vocational, secondary, and other) are used to count the number of respondents belonging to each education level.
Four variables (total1, total2, total3, and total4) are used to accumulate the sum of quality values for each education level.
An array lifeQualityEducationBased of size 4 is initialized to store the calculated average life quality for each education level.
Loop Through Responses:
The method iterates over each response in the table, starting from index 1 and to 300.
For each response, it retrieves the corresponding Response object from the table using table.search(i) method.
It then gets the education level of the respondent using value.getEducation().
Depending on the education level, it increments the corresponding count variable (primary, vocational, secondary, or other) and adds the quality value of the response to the respective total variable.

Calculate Mean:
After iterating through all responses, the method calculates the average quality for each education level by dividing the total quality for that level by the number of respondents with that education level.
The calculated mean values are stored in the lifeQualityEducationBased array.
Return Results:
Finally, the method returns the lifeQualityEducationBased array containing the average life quality for each education level.


mostCommonSymptoms(): identifies the most common symptoms reported by respondents based on their responses 

Var:
An array mostCommonSymptom of size 7 is used to count the occurrences of each symptom.
A HashMap<String, Integer> named map is used to store each symptom along with its count.
Counting Symptom Occurrences:
The method iterates over each response in the table (presumably 300 responses).
For each response, it retrieves the symptom field using value.getQ16().
It splits the symptom string using ";" as the delimiter and iterates over each individual symptom.
For each symptom encountered, it increments the corresponding count in the mostCommonSymptom array using a switch statement.
Storing Symptom Counts in HashMap:
After counting the occurrences of each symptom, the counts are stored in the map HashMap, with the symptom as the key and its count as the value.
Sorting Symptom Counts:
The symptom counts stored in the map are sorted based on their values (occurrence counts) in descending order.
This sorting is done using a List of Map Entries and a custom Comparator that sorts by value in reverse order.
Constructing Output Array:
After sorting, the sorted symptom counts are used to construct the output array symptomByNumber.
Each symptom is added to the array based on its frequency, starting from the most common symptom.
Return Results:
The method returns the symptomByNumber array containing the most common symptoms reported by respondents, sorted by frequency.



lifeQualityMixConditionsBased():calculates the average life quality score for two different conditions based on respondents' marital status and place of residence. 

Variables:
singleCityCount and marriedVillageTownCount are initialized to count the number of respondents falling into each condition category.
total1 and total2 are initialized to store the sum of life quality scores for each condition category.
lifeQualityMixConditionsBased is initialized as a double array of size 2 to store the average life quality scores for each condition.

Iterate Through Responses:
The method iterates over each response in the table (presumably 300 responses).
For each response, it retrieves the marital status and residence of the respondent using value.getMaritalStatus() and value.getResidence() respectively.

Counting and Summing Scores for Each Condition:
If the respondent is single and lives in a city (martial == 1 && residence == 4), the singleCityCount is incremented, and the life quality score for that respondent is added to total1.
If the respondent is married and lives in a village or town (martial == 2 && (residence == 1 || residence == 2)), the marriedVillageTownCount is incremented, and the life quality score for that respondent is added to total2.
Calculating Average Scores:
A
fter counting and summing the life quality scores for each condition category, the method calculates the average life quality score for each category.
This is done by dividing the total sum of life quality scores (total1 or total2) by the count of respondents (singleCityCount or marriedVillageTownCount) in that category.
Storing and Returning Results:
The average life quality scores for each condition category are stored in the lifeQualityMixConditionsBased array.
the method returns this array containing the average life quality scores for respondents based on their marital status and place of residence.



lifeQualityResponseBased(), calculates average life quality based on respondents' answers to question 15. 

 Variables:
Four variables (veryGood, Good, Bad, veryBad) are initialized to count the number of responses in each category.
Four variables (total1, total2, total3, total4) are initialized to store the sum of life quality scores for each category.
An array lifeQualityResponseBased of size 4 is created to store the results of life quality analysis based on responses to question 15.

Iteratation through responses:
The method iterates over each response in the table ( 300 responses).
For each response, it retrieves the response value to question 15 using value.getQ15().
Counting and Summing Scores for Each Response Category:
Depending on the response to question 15, the method increments the corresponding counter (veryGood, Good, Bad, veryBad) and adds the life quality score for that response to the respective total (total1, total2, total3, total4).

Calculating Average Scores:
After counting and summing the life quality scores for each response category, the method calculates the average life quality score for each category.
This is done by dividing the total sum of life quality scores (total1, total2, total3, total4) by the count of responses (veryGood, Good, Bad, veryBad) in each category.
Storing and Returning Results:
The average life quality scores for each response category are stored in the lifeQualityResponseBased array.
returns this array containing the average life quality scores based on respondents' answers to question 15.





