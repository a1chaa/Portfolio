
///Aichata Doumbia

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class SurveyDataAnalyzer {

    // This sets the instance of the table in the class to the table in SurveyData.
    private CustomHashTable table;

    // analyzes that table each instance of the class analyzes the table.
    public SurveyDataAnalyzer(CustomHashTable table) {
        this.table = table;
        
    }

   
    public int [] genderDistribution() {
        // represents 4 ints
        int []genderesponse = new int [4] ;
    
        // count every single response, it should be stored in the genderesponse arr.
        for(int i = 1; i<=300; i++){
            Response value = table.search(i);
            int gender= value.getGender();
            if(gender==1){
                //counter for number of women
                genderesponse[0]++ ;
    
            }
            else if (gender==2){
                //counter for number of men
                genderesponse[1]++ ;
            }
            else if (gender==3){
                genderesponse[2]++ ;
    
            }
            else if (gender==4){
                genderesponse[3]++ ;
            }
        }
    
        return genderesponse;
    
    }
    
   
    public int [] ageGroupDistribution() {
// Gets every response in the table and stores it in an array of entries

// Represents 4 ints
        int[] ageResponse = new int[4];

// Count every single response; it should be stored in the ageResponse array
        for (int i =1; i<=300; i++) {
            Response value = table.search(i);
            int age = value.getAge(); //  getAge() retrieves the age from the entry
            // Check which age group the current response belongs to and increment the corresponding counter
            // counter for response Below 30 years
            if (age == 1 ) {
                ageResponse[0]++;
            }
            //counter for 30-45 years (2)
            else if (age == 2){
                //counter for number of men
                ageResponse[1]++ ;
            }
// counter for 46-60 years (3)
            else if (age == 3){
                ageResponse[2]++ ;

            }
// counter for Above 60 years (4)
            else if (age == 4){
                ageResponse[3]++ ;
            }
        }
        return ageResponse;

    }

    public int[] residenceDistribution() { //removed the parameters to match Test cases from professor

        // Gets every response in the table and stores it in an array of entries
        //Entry[] responses = table.GetResponses();
// Represents 4 ints
        int[] residenceResponse = new int[4];


// Count every single response; it should be stored in the residenceResponse array
        for (int i = 1; i <= 300; i++) {
            Response value = table.search(i);
            int residence = value.getResidence();  // getresidence() retrieves the age from the entry
            // Check which residence the current response belongs to and increment the corresponding counter
            // counter for Village (1)
            if (residence == 1) {
                residenceResponse[0]++;
            }
            //counter for 100,000 inhabitants (2)
            else if (residence == 2) {
                residenceResponse[1]++;
            }
// counter for 100,000 to 500,000 inhabitants (3))
            else if (residence == 3) {
                residenceResponse[2]++;
            }
// over 500,000 inhabitants (4)
            else if (residence == 4) {
                residenceResponse[3]++;

            }
        }
        return residenceResponse;
    }



    public int[]  educationDistribution() {

        // Gets every response in the table and stores it in an array of entries
        // Represents 4 ints
        int[] educationResponse = new int[4];

        // Count every single response; it should be stored in the educationResponse array
        for (int i = 1; i <= 300; i++) {
            Response value = table.search(i);
            int education = value.getEducation(); //  getEducation() retrieves the edu  from the entry
            // Check which edu group the current response belongs to and increment the corresponding counter
            // counter for edu response  Primary (1)
            if (education == 1){
                educationResponse[0]++;
            }
            //counter edu  (2)
            else if (education == 2){
                //counter for edu Vocational (2)
                educationResponse[1]++ ;
            }
            // counter forSecondary (3)
            else if (education== 3){
                educationResponse[2]++ ;

            }
            // counter for Higher (4)
            else if (education == 4){
                educationResponse[3]++ ;
            }
        }
        return  educationResponse;

    }

    public int [] incomeDistribution() {

        // Gets every response in the table and stores it in an array of entries
        // Represents 4 ints
        int[] incomeResponse = new int[4];

        // Count every single response; it should be stored in treatmentResponse  array
        for (int i = 1; i <= 300; i++) {
            Response value = table.search(i);
            int income =value.getIncomeSource(); //  getIncome() retrieves the income  from the entry
            // Check which income group the current response belongs to and increment the corresponding counter

            // counter for income response Employment (1)
            if (income == 1) {
                incomeResponse[0]++;
            }
            //counter Pension (2)
            else if (income == 2){
                //counter for edu Vocational (2)
                incomeResponse[1]++ ;
            }
            // counter for Retirement (3)
            else if (income == 3){
                incomeResponse[2]++ ;

            }
            // counter for Other (4)
            else if (income == 4){
                incomeResponse[3]++ ;
            }
        }
        return  incomeResponse;

    }

    public int [] maritalDistribution() {
        // Gets every response in the table and stores it in an array of entries
        // Represents 4 ints
        int[] maritalResponse = new int[4];

        // Count every single response; it should be stored in martial response  array
        for (int i = 1; i <= 300; i++) {
            Response value = table.search(i);
            int maritalStatus = value.getMaritalStatus(); //  getmartialstatus() retrieves the status  from the entry
            // Check which income group the current response belongs to and increment the corresponding counter

            // counter for Single (1)
            if (maritalStatus == 1 ) {
                maritalResponse[0]++;
            }
            //counter Married (2)
            else if (maritalStatus == 2){

                maritalResponse[1]++ ;
            }
            // counter for Divorced (3)
            else if (maritalStatus == 3){
                maritalResponse[2]++ ;

            }
            // counter for Widowed (4)
            else if (maritalStatus == 4){
                maritalResponse[3]++ ;
            }
        }
        return  maritalResponse;

    }


    public int[] smokerDistribution() {
        int[] smokerResponse = new int[2];
        // Initialize counts
        int yes = 0;
        int no = 0;
    
        //This loop iterates over each entry 
        //in the data table, from index 1 to 300. For each index i
        for (int i = 1; i <= 300; i++) {
            Response value = table.search(i);//
            int smoker = value.getSmoker();
    
            // Increment the corresponding counter based on smoker status
            if (smoker == 0) {
                yes++; // Increment smoker count
            } else if (smoker == 1) {
                no++; // Increment non-smoker count
            }
        }
    
        // Assign counts to array
        smokerResponse[0] = yes;
        smokerResponse[1] = no;
    
        return smokerResponse;
    }
    
    
    
    public double lifeQualityGeneral() {
    double totalQuality = 0;
    for (int i = 1; i <= 300; i++) {
        Response value = table.search(i);
        totalQuality += value.getQuality();
    }
    // Divide the total quality by the number of responses (300)
    double mean = totalQuality / 300;
    return mean;
}


public double[] lifeQualityGenderBased() {
        double femaleCount = 0;
        double maleCount = 0;
        double otherCount = 0;
        double nCount = 0;
        
        double total1 = 0;
        double total2 = 0;
        double total3 = 0;
        double total4 = 0;
    
        // Loop through responses
        for (int i = 1; i <= 300; i++) {
            Response value = table.search(i);
            int gender = value.getGender();
    
            // Increment respective gender count and add quality to the total based on gender
            switch (gender) {
                case 1:
                    femaleCount++;
                    total1 += value.getQuality();
                    break;
                case 2:
                    maleCount++;
                    total2 += value.getQuality();
                    break;
                case 3: // Should this be "other" instead of "0"?
                    otherCount++;
                    total3 += value.getQuality();
                    break;
                case 4:
                    nCount++;
                    total4 += value.getQuality();
                    break;
                default:
                    break;
            }
        }
    
        // Calculate averages
        double[] lifeQualityGenderBased = new double[4];
        
            lifeQualityGenderBased[0] = total1/femaleCount;
            lifeQualityGenderBased[1]=total2/maleCount;
            lifeQualityGenderBased[2]=total3/otherCount;
            lifeQualityGenderBased[3]=total4/nCount;

    return lifeQualityGenderBased;

}

    
public double [] lifeQualityAgeBased(){
        
            
        
            double group1 = 0;
            double group2 = 0;
            double group3 = 0;
            double group4 = 0;
        
            double total1 = 0;
            double total2 = 0;
            double total3 = 0;
            double total4 = 0;
        
            double[] lifeQualityAgeBased = new double[4];
        
        
            for (int i =1; i<=300; i++) {
                Response value = table.search(i);
                int age = value.getAge();
                // checks
                //quotation mark fix
                if(age==1){
                    //if it is F then increment Female
                    group1++;
                    total1+=value.getQuality();
        
                }
                if(age==2){
                    //if it isM then increment male
                    group2++;
                    total2+=value.getQuality();
        
                }
        
                if(age==3){
                    //if it is O then increment Other
                    group3++;
                    total3+=value.getQuality();
        
                }
                if(age==4){
                    //if it is N then increment Other
                    group4++;
                    total4+=value.getQuality();
                }
                }
            
        lifeQualityAgeBased[0] = total1/group1;
        lifeQualityAgeBased[1]=total2/group2;
        lifeQualityAgeBased[2]=total3/group3;
        lifeQualityAgeBased[3]=total4/group4;
    
        return lifeQualityAgeBased;
    
    }
    
        
        public double [] lifeQualityResidenceBased (){
            double residence1 =0;
            double residence2=0;
            double residence3=0;
            double residence4=0;
        
            double total1 = 0;
            double total2 = 0;
            double total3 = 0;
            double total4 = 0;
        
            double[] lifeQualityResidenceBased = new double[4];
        
        
            for (int i =1; i<=300; i++) {
                Response value = table.search(i);
                int res = value.getResidence();
                // checks
                //quotation mark fix
                if(res==1){
                    //if it is F then increment Female
                    residence1++;
                    total1+=value.getQuality();
        
                }
                if(res==2){
                    //if it isM then increment male
                    residence2++;
                    total2+=value.getQuality();
        
                }
        
                if(res==3){
                    //if it is O then increment Other
                    residence3++;
                    total3+=value.getQuality();
        
                }
                if(res==4){
                    //if it is N then increment Other
                    residence4++;
                    total4+=value.getQuality();
        
                }
            }
            lifeQualityResidenceBased[0] = total1/residence1;
            lifeQualityResidenceBased[1]=total2/residence2;
            lifeQualityResidenceBased[2]=total3/residence3;
            lifeQualityResidenceBased[3]=total4/residence4;
        
            return lifeQualityResidenceBased;
        }
        
    
    public double[] lifeQualityEducationBased (){
        double primary =0;
        double vocational=0;
        double secondary=0;
        double other=0;
        double total1 = 0;
        double total2 = 0;
        double total3 = 0;
        double total4 = 0;
        double[] lifeQualityEducationBased = new double[4];
    
        //quoatation mark fix
        for (int i =1; i<=300; i++) {
            Response value = table.search(i);
            int edu = value.getEducation();
            // checks
            if(edu==1){
                //if it is F then increment Female
                primary++;
                total1+=value.getQuality();
    
            }
    
            if(edu==2){
                //if it is second then increment second response
                vocational++;
                total2+=value.getQuality();
    
            }
    
            if(edu==3){
                //if it is third then increment third response
                secondary++;
                total3+=value.getQuality();
    
            }
    
            if(edu==4){
                //if it 4th education then increment that response
                other++;
                total4+=value.getQuality();
    
            }
        }
        lifeQualityEducationBased[0] = total1/primary;
        lifeQualityEducationBased[1] = total2/vocational;
        lifeQualityEducationBased[2] = total3/secondary;
        lifeQualityEducationBased[3] = total4/other;
    
        return lifeQualityEducationBased;
    }
    
    public double[] lifeQualityIncomeBased (){
        double employment =0;
        double pension =0;
        double retirement=0;
        double other =0;
        double total1 = 0;
        double total2 = 0;
        double total3 = 0;
        double total4 = 0;
        
    
        double[]lifeQualityIncomeBased = new double [4];
    
        for (int i =1; i<=300; i++) {
            // checks
            Response value = table.search(i);
            int income = value.getIncomeSource();
            
            if(income==1){
    
                employment++;
                        total1+= value.getQuality();
    
            }
    
            if(income==2){
                //if it is second then increment second response
               pension++;
                total2 += value.getQuality();
    
            }
    
    
            if(income==3){
                //if it is third then increment third response
                retirement++;
                total3+= value.getQuality();
    
            }
    
            if(income==4){
                //if it 4th then increment that response
                other++;
                 total4+= value.getQuality();
    
            }
        }
        lifeQualityIncomeBased[0] = total1/employment;
        lifeQualityIncomeBased[1]=total2/pension;
        lifeQualityIncomeBased[2]=total3/retirement;
        lifeQualityIncomeBased[3]=total4/other;
    
    
        return lifeQualityIncomeBased;
    }
    
    public double[] lifeQualityMaritalBased  (){
        double single =0;
        double married =0;
        double divorce =0;
        double widowed=0;
        double total1 = 0;
        double total2 = 0;
        double total3 = 0;
        double total4 = 0;
        
       
    
        double[]lifeQualityMaritalBased = new double [4];
    
        for (int i =1; i<=300; i++) {
            // checks
            Response value = table.search(i);
            int martial = value.getMaritalStatus();
            
            if(martial==1){
    
                single++;
                        total1+= value.getQuality();
    
            }
    
            if(martial==2){
                //if it is second then increment second response
               married++;
                total2 += value.getQuality();
    
            }
    
    
            if(martial==3){
                //if it is third then increment third response
                divorce++;
                total3+= value.getQuality();
    
            }
    
            if(martial==4){
                //if it 4th then increment that response
                widowed++;
                 total4+= value.getQuality();
    
            }
        }
        /*
         the average life quality score for each marital status 
         category by dividing the total sum of life quality scores 
         (total1, total2, total3, or total4) by the count 
         of respondents (single, married, divorce, or widowed) in that category.
         */
        lifeQualityMaritalBased [0] = total1/single;
        lifeQualityMaritalBased [1]=total2/married;
        lifeQualityMaritalBased [2]=total3/divorce;
        lifeQualityMaritalBased [3]=total4/widowed;
    
    
        return lifeQualityMaritalBased ;
    }
    
        public double[] lifeQualitySmokerBased (){
            double yes =0;
            double no =0;
        
            double total1 = 0;
            double total2 = 0;
            double[] lifeQualitySmokerBased = new double[2];
        
            for (int i=1; i<=300; i++) {
                // checks
                Response value = table.search(i);
                int smoker = value.getSmoker();
                if(smoker==1){
                    yes++;
                    total1+= value.getQuality();
        
                }
        
                if(smoker==0){
                    //if it is second then increment second response
                    no++;
                    total2+=value.getQuality();
        
                }
            }
        
            lifeQualitySmokerBased[0] = total1/yes;
            lifeQualitySmokerBased[1] = total2/no;
        
        
            return lifeQualitySmokerBased;
        }
        
            //  Array list of treatment
            public String[] mostCommonTreatment() {
    int[] mostCommonTreatment = new int[5];
    HashMap<String, Integer> map = new HashMap<>();

    // Assuming you have a table with responses and each response has a treatment field
    for (int i = 1; i <= 300; i++) {
        Response value = table.search(i);
        String treatment = value.getQ9();
        String[] treatments = treatment.split(";");
        for (String t : treatments) {
            switch (t) {
                case "Surgical":
                    mostCommonTreatment[0]++;
                    break;
                case "Chemotherapy":
                    mostCommonTreatment[1]++;
                    break;
                case "Radiotherapy":
                    mostCommonTreatment[2]++;
                    break;
                case "Immunotherapy":
                    mostCommonTreatment[3]++;
                    break;
                case "MolecularlyTargetedTherapy":
                    mostCommonTreatment[4]++;
                    break;
                default:
                    break;
            }
        }
    }
//putting in map
    map.put("Surgical", mostCommonTreatment[0]);
    map.put("Chemotherapy", mostCommonTreatment[1]);
    map.put("Radiotherapy", mostCommonTreatment[2]);
    map.put("Immunotherapy", mostCommonTreatment[3]);
    map.put("MolecularlyTargetedTherapy", mostCommonTreatment[4]);

    // Sorting the treatments by frequency
    List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(map.entrySet());
    sortedEntries.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));

    // Constructing the output array
    String[] treatmentByNumber = new String[sortedEntries.size()];
    for (int i = 0; i < sortedEntries.size(); i++) {
        treatmentByNumber[i] = sortedEntries.get(i).getKey();
    }

    return treatmentByNumber;
}

    
    
public String[] mostCommonSymptoms() {
    int[] mostCommonSymptom = new int[7];
    HashMap<String, Integer> map = new HashMap<>();

    // Assuming you have a table with responses and each response has a symptom field
    for (int i = 1; i <= 300; i++) {
        Response value = table.search(i);
        String symptom = value.getQ16();
        String[] symptoms = symptom.split(";");
        for (String s : symptoms) {
            switch (s) {
                case "Weakness":
                    mostCommonSymptom[0]++;
                    break;
                case "Cough":
                    mostCommonSymptom[1]++;
                    break;
                case "None":
                    mostCommonSymptom[2]++;
                    break;
                case "ShortnessOfBreath":
                    mostCommonSymptom[3]++;
                    break;
                case "ChestPain":
                    mostCommonSymptom[4]++;
                    break;
                case "Hoarseness":
                    mostCommonSymptom[5]++;
                    break;
                case "CoughingUpBlood":
                    mostCommonSymptom[6]++;
                    break;
                default:
                    break;
            }
        }
    }
    
    //putting in map
    map.put("Weakness", mostCommonSymptom[0]);
    map.put("Cough", mostCommonSymptom[1]);
    map.put("None", mostCommonSymptom[2]);
    map.put("ShortnessOfBreath", mostCommonSymptom[3]);
    map.put("ChestPain", mostCommonSymptom[4]);
    map.put("Hoarseness", mostCommonSymptom[5]);
   map.put("CoughingUpBlood", mostCommonSymptom[6]);
   
    // Sorting the symptoms by frequency
    List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(map.entrySet());
    sortedEntries.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));

    // Constructing the output array
    String[] symptomByNumber = new String[sortedEntries.size()];
    for (int i = 0; i < sortedEntries.size(); i++) {
        symptomByNumber[i] = sortedEntries.get(i).getKey();
    }

    return symptomByNumber;
}

    
public String[] mostCommonLifeAspects() {
    int[] mostCommonLifeAspects = new int[6];
    HashMap<String, Integer> map = new HashMap<>();

    
    for (int i = 1; i <= 300; i++) {
        Response value = table.search(i);
        String aspect = value.getQ23();
        String[] aspects = aspect.split(";");
        for (String s : aspects) {
            switch (s) {
                
                case "PsychologicalAspect":
                mostCommonLifeAspects[0]++;
                    break;
                case "PhysicalAspect":
                mostCommonLifeAspects[1]++;
                    break;
                case "DoesNotAffect":
                mostCommonLifeAspects[2]++;
                    break;
                case "ProfessionalLife":
                mostCommonLifeAspects[3]++;
                    break;
                case "FamilyLife":
                mostCommonLifeAspects[4]++;
                    break;
                case "SocialLife":
                mostCommonLifeAspects[5]++;
                    break;
                default:
                    break;
            }
        }
    }
    //putting in map
    map.put("PsychologicalAspect", mostCommonLifeAspects[0]);
    map.put("PhysicalAspect", mostCommonLifeAspects[1]);
    map.put("DoesNotAffect", mostCommonLifeAspects[2]);
    map.put("ProfessionalLife", mostCommonLifeAspects[3]);
    map.put("FamilyLife", mostCommonLifeAspects[4]);
    map.put("SocialLife", mostCommonLifeAspects[5]);
   
   
    // Sorting the aspect by frequency
    List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(map.entrySet());
    sortedEntries.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));

    // Constructing the output array
    String[] aspectByNumber = new String[sortedEntries.size()];
    for (int i = 0; i < sortedEntries.size(); i++) {
        aspectByNumber[i] = sortedEntries.get(i).getKey();
    }

    return aspectByNumber;
}

public double[] lifeQualityMixConditionsBased (){
//variables
    double singleCityCount = 0;
    double marriedVillageTownCount = 0;
    double total1 = 0;
    double total2 = 0;
    double[]lifeQualityMixConditionsBased = new double [2];

    for (int i =1; i<=300; i++) {
        // checks
        Response value = table.search(i);
        int martial = value.getMaritalStatus();
        int residence = value.getResidence();
        // if singleand city
        if(martial==1 && residence==4){

            singleCityCount++;
            total1+= value.getQuality();

        }
    // if married and village or town
        if(martial==2 && residence==1 || martial==2 && residence==2){
            //if it is second then increment second response
            marriedVillageTownCount++;
           total2 += value.getQuality();

        }


        

       
    }
   /*
    calculates the average life quality score for each condition category 
    by dividing the total sum of life quality scores (total1 or total2) by 
    the count of respondents 
    (singleCityCount or marriedVillageTownCount) in that category.
 */
   
    lifeQualityMixConditionsBased [0] = total1/ singleCityCount;
    lifeQualityMixConditionsBased [1]=total2/ marriedVillageTownCount;
    


    return lifeQualityMixConditionsBased ;
}

public double[] lifeQualityResponseBased (){
//variables
    double veryGood =0;
    double Good =0;
    double Bad =0;
    double veryBad =0;
    double total1 = 0;
    double total2 = 0;
    double total3 = 0;
    double total4 = 0;
    // Array to store the results of life quality analysis based on response to question 15
    double[]lifeQualityResponseBased = new double [4];

    for (int i =1; i<=300; i++) {
        // checks
        /*
         retrieves the Response object associated with the index i from the table.
        value.getQ15() retrieves the value of the response to 
        question 15 (denoted as Q15) from the Response object value 

         */
        
        Response value = table.search(i);
         int quality = value.getQ15();
       
        if(quality==1){
            veryGood++;
            total1+= value.getQuality();
            
        }

            if(quality==2){
            Good++;
            total2+= value.getQuality();

        }

        if(quality==3){
            //if it is 3 then increment 3 response
            Bad++;
           total3 += value.getQuality();

        }

        if(quality==4){
            //if it is 4 then increment 4 response
            veryBad++;
           total4 += value.getQuality();

        }
        

       
    }
    
    /*
    Each division calculates the average life quality score for each 
    response category by dividing the total sum of life quality scores 
    (total1, total2, total3, or total4) 
    by the count of responses (veryGood, Good, Bad, or veryBad) in that category.
     */
    lifeQualityResponseBased [0] = total1/ veryGood;
    lifeQualityResponseBased [1]=total2/ Good;
    lifeQualityResponseBased [2] = total3/ Bad;
    lifeQualityResponseBased [3]=total4/ veryBad;


    return lifeQualityResponseBased ;
}
    
    
   
















public static void main(String[] args) throws IOException {
        // main problem still is iterating through HashTable to get keys that are actually in the table.
        SurveyDataAnalyzer analyzer = new SurveyDataAnalyzer(ReadFile.readResponsesFromFile("responses.txt"));

        System.out.println();
        int[] Question1 = analyzer.genderDistribution(); // Call the method to get the test results
        System.out.print("Gender Distribution: " );
        for (int x: Question1){
            System.out.print(x + " ");
        }
        System.out.println();
        
        int[] Question2 = analyzer.ageGroupDistribution(); // Call the method to get the test results
        System.out.print("Age Group Distribution: " );
        for (int x: Question2){
            System.out.print(x + " ");
        }
        System.out.println();
        int[] Question3 = analyzer.residenceDistribution(); // Call the method to get the test results
        System.out.print("Residence Distribution: " );
        for (int x: Question3){
            System.out.print(x + " ");
        }
        
        System.out.println();
        int[] Question4 = analyzer.educationDistribution(); // Call the method to get the test results
        System.out.print("Education Distribution: " );
        for (int x: Question4){
            System.out.print(x + " ");
        }
        
        System.out.println();
        int[] Question5 = analyzer.incomeDistribution(); // Call the method to get the test results
        System.out.print("Income Distribution: " );
        for (int x: Question5){
            System.out.print(x + " ");
        }
        
        System.out.println();
        int[] Question6 = analyzer.maritalDistribution(); // Call the method to get the test results
        System.out.print("Marital Distribution: " );
        for (int x: Question6){
            System.out.print(x + " ");
        }
        
        
        System.out.println();
        int[] Question7 = analyzer.smokerDistribution(); // Call the method to get the test results
        System.out.print("Smoker Distribution: " );
        for (int x: Question7){
            System.out.print(x + " ");
        }
        System.out.println();
        
        System.out.println();
        double Question8 = analyzer.lifeQualityGeneral(); // Call the method to get the test results
        System.out.print("Life Quality in General: " + Question8);
        System.out.println();

       
        
         double [] Question9 = analyzer.lifeQualityGenderBased(); // Call the method to get the test results
        System.out.print("Life Quality in GenderBased: " );
        for (double x: Question9){
            System.out.print(x + " ");
        }

        
        System.out.println();
         double [] Question10 = analyzer.lifeQualityAgeBased(); // Call the method to get the test results
        System.out.print("Life Quality in AgeBased: " );
        for (double x: Question10){
            System.out.print(x + " ");
        }
        
        
        
        System.out.println();
         double [] Question11 = analyzer.lifeQualityResidenceBased(); // Call the method to get the test results
         System.out.print("Life Quality in ResidenceBased: " );
         for (double x: Question11){
            System.out.print(x + " ");
        }
        
        
        
        
        System.out.println();
         double [] Question12 = analyzer. lifeQualityEducationBased (); // Call the method to get the test results
        System.out.print("Life Quality in EducationBased: " );
        for (double x: Question12){
            System.out.print(x + " ");
        }
        System.out.println();
        
        System.out.println();
         double[] Question13 = analyzer. lifeQualityIncomeBased (); // Call the method to get the test results
        System.out.print("life Quality IncomeBased: " );
        for (double x: Question13){
            System.out.print(x + " ");
        }
       
       
       
       
        System.out.println();
        double [] Question14= analyzer. lifeQualityMaritalBased (); // Call the method to get the test results
       System.out.print("life Quality MaritalBased: " );
       for (double x: Question14){
        System.out.print(x + " ");
    }
       
       
       System.out.println();
        double [] Question15 = analyzer. lifeQualitySmokerBased (); // Call the method to get the test results
       System.out.print("life Quality SmokerBased: " );
       for (double x: Question15){
        System.out.print(x + " ");
    }
       
    System.out.println();
       System.out.println();
    String[] mostCommonTreatment = analyzer.mostCommonTreatment();
    System.out.print("Most Common Treatment: ");
    for (String treatment : mostCommonTreatment) {
        System.out.print(treatment + " ");
    }
    
    
        
        System.out.println();
        String[] mostCommonSymptoms = analyzer.mostCommonSymptoms();
    System.out.print("Most Common Symptoms: ");
    for (String symptom : mostCommonSymptoms) {
        System.out.print(symptom + " ");
    }
    System.out.println();
    
       
    System.out.println();
        double [] Question18 = analyzer.lifeQualityMixConditionsBased(); // Call the method to get the test results
        System.out.print("life Quality Mix Conditions Based " );
        for (double x: Question18){
            System.out.print(x + " ");
        }
        System.out.println();
        double [] Question19 = analyzer.lifeQualityResponseBased(); // Call the method to get the test results
        System.out.print("life Quality Response Based: " );
        for (double x: Question19){
            System.out.print(x + " ");
        }
    
        String [] Question20 = analyzer.mostCommonLifeAspects();; // Call the method to get the test results
        System.out.print("Most Common Life Aspects: " );
        for (String x: Question20){
            System.out.print(x + " ");
        }
    
    
        
    
        













        
    
        

        
    }
}
