public class Main {
    public static void main(String[] args) {
        String filePath = "./responses.txt";  // Adjust the path as necessary

         //create an instance of CustomHashTable with survey data
         CustomHashTable table = ReadFile.readResponsesFromFile(filePath);
         //create an instance of SurveyDataAnalyzer with the CustomHashTable instance
        SurveyDataAnalyzer analyzer = new SurveyDataAnalyzer(table); // Passing table to the analyzer

        //printing results of each method
        printIntArray("Gender Distribution", analyzer.genderDistribution());
        printIntArray("Age Group Distribution", analyzer.ageGroupDistribution());
        printIntArray("Residence Distribution", analyzer.residenceDistribution());
        printIntArray("Education Distribution", analyzer.educationDistribution());
        printIntArray("Income Distribution", analyzer.incomeDistribution());
        printIntArray("Marital Distribution", analyzer.maritalDistribution());
        printIntArray("Smoker Distribution", analyzer.smokerDistribution());
        System.out.println("General Life Quality: " + analyzer.lifeQualityGeneral());
        printDoubleArray("Life Quality Gender Based", analyzer.lifeQualityGenderBased());
        printDoubleArray("Life Quality Age Based", analyzer.lifeQualityAgeBased());
        printDoubleArray("Life Quality Residence Based", analyzer.lifeQualityResidenceBased());
        printDoubleArray("Life Quality Education Based", analyzer.lifeQualityEducationBased());
        printDoubleArray("Life Quality Income Based", analyzer.lifeQualityIncomeBased());
        printDoubleArray("Life Quality Marital Based", analyzer.lifeQualityMaritalBased());
        printDoubleArray("Life Quality Smoker Based", analyzer.lifeQualitySmokerBased());
        printStringArray("Most Common Treatment", analyzer.mostCommonTreatment());
        printStringArray("Most Common Symptoms", analyzer.mostCommonSymptoms());
        printStringArray("Most Common Life Aspects", analyzer.mostCommonLifeAspects());
        printDoubleArray("Life Quality Mix Conditions Based", analyzer.lifeQualityMixConditionsBased());
        printDoubleArray("Life Quality Response Based", analyzer.lifeQualityResponseBased());

    }

    //method to print an int array
    public static void printIntArray(String label, int[] array) {
        System.out.print(label + ": ");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void printDoubleArray(String label, double[] array) {
        System.out.print(label + ": ");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void printStringArray(String label, String[] array) {
        System.out.print(label + ": ");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }
}
