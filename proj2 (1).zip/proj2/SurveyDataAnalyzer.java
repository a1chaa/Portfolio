import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;

public class SurveyDataAnalyzer {

    private CustomHashTable table;

    public SurveyDataAnalyzer(CustomHashTable table) {
        this.table = table;
    }

    public int[] genderDistribution() {
        int[] genderResponse = new int[4]; 
    
        for (Response response : table.getResponses()) {
            String gender = response.getGender();
            switch (gender) {
                case "F":
                    genderResponse[0]++; 
                    break;
                case "M":
                    genderResponse[1]++; 
                    break;
                case "O":
                    genderResponse[2]++; 
                    break;
                case "-":
                    genderResponse[3]++; 
                    break;
            }
        }
        return genderResponse;
    }
    

    public int[] ageGroupDistribution() {
        int[] ageResponse = new int[4];
        for (Response response : table.getResponses()) {
            int age = response.getAge();
            if (age >= 1 && age <= 4) {
                ageResponse[age - 1]++;
            }
        }
        return ageResponse;
    }

    public int[] residenceDistribution() {
        int[] residenceResponse = new int[4];
        for (Response response : table.getResponses()) {
            int residence = response.getResidence();
            if (residence >= 1 && residence <= 4) {
                residenceResponse[residence - 1]++;
            }
        }
        return residenceResponse;
    }

    public int[] educationDistribution() {
        int[] educationResponse = new int[4];
        for (Response response : table.getResponses()) {
            int education = response.getEducation();
            if (education >= 1 && education <= 4) {
                educationResponse[education - 1]++;
            }
        }
        return educationResponse;
    }

    public int[] incomeDistribution() {
        int[] incomeResponse = new int[4];
        for (Response response : table.getResponses()) {
            int incomeSource = response.getIncomeSource();
            if (incomeSource >= 1 && incomeSource <= 4) {
                incomeResponse[incomeSource - 1]++;
            }
        }
        return incomeResponse;
    }

    public int[] maritalDistribution() {
        int[] maritalResponse = new int[4];
        for (Response response : table.getResponses()) {
            int maritalStatus = response.getMaritalStatus();
            if (maritalStatus >= 1 && maritalStatus <= 4) {
                maritalResponse[maritalStatus - 1]++;
            }
        }
        return maritalResponse;
    }

    public int[] smokerDistribution() {
        int[] smokerResponse = new int[2]; 
        for (Response response : table.getResponses()) {
            int smoker = response.getSmoker();
            if (smoker == 1 || smoker == 2) {
                smokerResponse[smoker - 1]++;
            }
        }
        return smokerResponse;
    }

    public double lifeQualityGeneral() {
        double totalQuality = 0;
        int count = 0;
        for (Response response : table.getResponses()) {
            totalQuality += response.getQuality();
            count++;
        }
        return count > 0 ? totalQuality / count : 0;
    }

    public double[] lifeQualityGenderBased() {
        double[] totals = new double[4]; 
        int[] counts = new int[4];       
    
        for (Response response : table.getResponses()) {
            String gender = response.getGender();
            int index = -1;
    
            switch (gender) {
                case "F":
                    index = 0; 
                    break;
                case "M":
                    index = 1;
                    break;
                case "O":
                    index = 2; 
                    break;
                case "-":
                    index = 3; 
                    break;
            }
    
            if (index != -1) {
                totals[index] += response.getQuality();
                counts[index]++;
            }
        }
    
        double[] averages = new double[4];
        for (int i = 0; i < 4; i++) {
            averages[i] = counts[i] > 0 ? totals[i] / counts[i] : 0;
        }
        return averages;
    }
    
    public double[] lifeQualityAgeBased() {
        double[] totals = new double[4]; 
        int[] counts = new int[4];       
        for (Response response : table.getResponses()) {
            int ageGroup = response.getAge();
            if (ageGroup >= 1 && ageGroup <= 4) {
                totals[ageGroup - 1] += response.getQuality();
                counts[ageGroup - 1]++;
            }
        }
        double[] averages = new double[4];
        for (int i = 0; i < 4; i++) {
            averages[i] = counts[i] > 0 ? totals[i] / counts[i] : 0;
        }
        return averages;
    }

    public double[] lifeQualityResidenceBased() {
        double[] totals = new double[4]; 
        int[] counts = new int[4];       
        for (Response response : table.getResponses()) {
            int residence = response.getResidence();
            if (residence >= 1 && residence <= 4) {
                totals[residence - 1] += response.getQuality();
                counts[residence - 1]++;
            }
        }
        double[] averages = new double[4];
        for (int i = 0; i < 4; i++) {
            averages[i] = counts[i] > 0 ? totals[i] / counts[i] : 0;
        }
        return averages;
    }

    public double[] lifeQualityEducationBased() {
        double[] totals = new double[4]; 
        int[] counts = new int[4];       
        for (Response response : table.getResponses()) {
            int education = response.getEducation();
            if (education >= 1 && education <= 4) {
                totals[education - 1] += response.getQuality();
                counts[education - 1]++;
            }
        }
        double[] averages = new double[4];
        for (int i = 0; i < 4; i++) {
            averages[i] = counts[i] > 0 ? totals[i] / counts[i] : 0;
        }
        return averages;
    }

    public double[] lifeQualityIncomeBased() {
        double[] totals = new double[4]; 
        int[] counts = new int[4];       
        for (Response response : table.getResponses()) {
            int income = response.getIncomeSource();
            if (income >= 1 && income <= 4) {
                totals[income - 1] += response.getQuality();
                counts[income - 1]++;
            }
        }
        double[] averages = new double[4];
        for (int i = 0; i < 4; i++) {
            averages[i] = counts[i] > 0 ? totals[i] / counts[i] : 0;
        }
        return averages;
    }

    public double[] lifeQualityMaritalBased() {
        double[] totals = new double[4]; 
        int[] counts = new int[4];       
        for (Response response : table.getResponses()) {
            int maritalStatus = response.getMaritalStatus();
            if (maritalStatus >= 1 && maritalStatus <= 4) {
                totals[maritalStatus - 1] += response.getQuality();
                counts[maritalStatus - 1]++;
            }
        }
        double[] averages = new double[4];
        for (int i = 0; i < 4; i++) {
            averages[i] = counts[i] > 0 ? totals[i] / counts[i] : 0;
        }
        return averages;
    }
    public double[] lifeQualityMixConditionsBased() {
        double sumSingleCity = 0, sumMarriedVillage = 0;
        int countSingleCity = 0, countMarriedVillage = 0;
    
        for (Response response : table.getResponses()) {
            int residence = response.getResidence();
            int maritalStatus = response.getMaritalStatus();
    
            if (response.getMaritalStatus() == 1 && response.getResidence() == 4) {  
                sumSingleCity += response.getQuality();
                countSingleCity++;
            } else if (response.getMaritalStatus() == 2 && (residence == 1 || residence == 2)) {  
                sumMarriedVillage += response.getQuality();
                countMarriedVillage++;
            }
        }
    
        double avgSingleCity = countSingleCity > 0 ? sumSingleCity / countSingleCity : 0;
        double avgMarriedVillage = countMarriedVillage > 0 ? sumMarriedVillage / countMarriedVillage : 0;
    
        return new double[] {avgSingleCity, avgMarriedVillage};
    }
    public double[] lifeQualityResponseBased() {
        double[] sums = new double[4]; 
        int[] counts = new int[4];     
    
        for (Response response : table.getResponses()) {
            int responseIndex = response.getQ15() - 1;  
            if (responseIndex >= 0 && responseIndex < 4) {
                sums[responseIndex] += response.getQuality();
                counts[responseIndex]++;
            }
        }
    
        double[] averages = new double[4];
        for (int i = 0; i < 4; i++) {
            averages[i] = counts[i] > 0 ? sums[i] / counts[i] : 0; 
        }
    
        return averages;
    }
    
    
    public double[] lifeQualitySmokerBased() {
        double[] totals = new double[2];
        int[] counts = new int[2];       
        for (Response response : table.getResponses()) {
            int smoker = response.getSmoker();
            if (smoker == 1 || smoker == 2) {
                int index = smoker - 1;  
                totals[index] += response.getQuality();
                counts[index]++;
            }
        }
        double[] averages = new double[2];
        for (int i = 0; i < 2; i++) {
            averages[i] = counts[i] > 0 ? totals[i] / counts[i] : 0;
        }
        return averages;
    }

    public String[] mostCommonTreatment() {
        Map<String, Integer> treatmentCounts = new HashMap<>();
        for (Response response : table.getResponses()) {
            String treatments = response.getQ9(); 
            if (treatments != null && !treatments.isEmpty()) {
                String[] splitTreatments = treatments.split(";");
                for (String treatment : splitTreatments) {
                    treatmentCounts.put(treatment, treatmentCounts.getOrDefault(treatment, 0) + 1);
                }
            }
        }
        return getTopItems(treatmentCounts, 5); 
    }

    public String[] mostCommonSymptoms() {
        Map<String, Integer> symptomCounts = new HashMap<>();
        for (Response response : table.getResponses()) {
            String symptoms = response.getQ16(); 
            if (symptoms != null && !symptoms.isEmpty()) {
                String[] splitSymptoms = symptoms.split(";");
                for (String symptom : splitSymptoms) {
                    symptomCounts.put(symptom, symptomCounts.getOrDefault(symptom, 0) + 1);
                }
            }
        }
        return getTopItems(symptomCounts, 6); 
    }

    public String[] mostCommonLifeAspects() {
        Map<String, Integer> lifeAspectCounts = new HashMap<>();
        for (Response response : table.getResponses()) {
            String aspects = response.getQ23(); 
            if (aspects != null && !aspects.isEmpty()) {
                String[] splitAspects = aspects.split(";");
                for (String aspect : splitAspects) {
                    lifeAspectCounts.put(aspect, lifeAspectCounts.getOrDefault(aspect, 0) + 1);
                }
            }
        }
        return getTopItems(lifeAspectCounts, 5); 
    }

    private String[] getTopItems(Map<String, Integer> itemCounts, int topN) {
        List<Map.Entry<String, Integer>> list = new ArrayList<>(itemCounts.entrySet());
        list.sort(Map.Entry.comparingByValue(Collections.reverseOrder()));

        String[] topItems = new String[Math.min(topN, list.size())];
        for (int i = 0; i < topItems.length; i++) {
            topItems[i] = list.get(i).getKey() + " (" + list.get(i).getValue() + ")";
        }
        return topItems;
    }
}

